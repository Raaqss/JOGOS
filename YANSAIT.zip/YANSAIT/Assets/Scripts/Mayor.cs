﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mayor : MonoBehaviour
{
    // Start is called before the first frame update
    //Animation animator;
    //AnimationClip movment;
    Vector2 position;
    public float speed;
    public GameObject character;
    Rigidbody2D fisica;
    Animator ani;
    void Start()
    {
        //animator = GetComponent<Animation>();
        fisica = GetComponent<Rigidbody2D>();
        ani = GetComponent<Animator>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        //animator.clip = movment;
        if (Time.timeSinceLevelLoad >= 6 && Time.timeSinceLevelLoad <=11.5f) {
            position = new Vector2(-11.91f, -2.22f);
            fisica.AddForce(position * speed);
             }
        if (Time.timeSinceLevelLoad >= 11.6 && Time.timeSinceLevelLoad <= 12.3)
        {
            fisica.AddForce(position * 0);
            ani.speed = 0;
        }
        if(Time.timeSinceLevelLoad >=155 && Time.timeSinceLevelLoad <= 157)
        {
            Destroy(character);
        }
            //animator.Play();

    }
}
