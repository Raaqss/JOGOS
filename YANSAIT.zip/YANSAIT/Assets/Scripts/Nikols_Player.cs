﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class Nikols_Player : MonoBehaviour
{
    //Rigidbody2D p;
    public float speed;
    Animator a;
    public GameObject box;
    public GameObject cena_princ;
    public GameObject lim_princ;
    public GameObject corredor;
    public GameObject lim_corr;
    public GameObject bath;
    public GameObject lim_bath;
    public GameObject triggbath;
    public GameObject saidap1;
    public GameObject personagem;
    public GameObject enemy;
    public GameObject telacombate;
    public GameObject textocombate;
    public GameObject obj1;
    public Text texto;
    public Text sortt;


 
    public BoxCollider2D cabana1;
    public BoxCollider2D porta1;
    //public BoxCollider2D porta2;
    //public BoxCollider2D porta3;
    //public BoxCollider2D porta4;

    float trigg = 0;
    int varenemy = 0;
    string[] bath_obj = { "SINK", "WASHING MACHINE", "PLUNGER", "TOILET", "TOWEL", "SHOWER", "BATHTUB" };
    int sort;
    string output;
    int combate;
    int count = 0;




    // Start is called before the first frame update
    void Start()
    {

        a = GetComponent<Animator>();

        
    }

// Update is called once per frame

void Update() {
    //declaração de variáveis
    int windoor1 = 0;
    // int door2 = 0;
    // int windoor2 = 0;
    // int door3 = 0;
    // int door4 = 0;
    // int windoor3 = 0;

    Movimentacao();


    //Entrada na primeira cabana

    if (trigg == 1) {
        if (Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.E))
        {
            cena_princ.gameObject.SetActive(false);
            personagem.gameObject.transform.position = (new Vector2(-18.34325f, -0.221618f));
            corredor.gameObject.SetActive(true);
            lim_princ.gameObject.SetActive(false);
            lim_corr.gameObject.SetActive(true);
            cabana1.gameObject.SetActive(false);
            trigg = 0;

        }
    }

    //Se o personagem estiver longe de um objeto (ou seja, se o trigg = 0, então a caixa com o texto deve sumir da tela
    if (trigg == 0 && texto.gameObject.active == true)
    {
        texto.gameObject.SetActive(false);
        box.gameObject.SetActive(false);
    }

    //chamando método da primeira porta caso trigger seja disparado
    if (trigg == 2 && varenemy == 0)
    {
        if (Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.E))
        {
            PrimeiraPorta();
            triggbath.gameObject.SetActive(true);
        }
    }
    //Objeto washing machine
    if (trigg == 3 && varenemy == 0)
    {
        if (Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.E))
        {
            box.gameObject.SetActive(true);
            texto.gameObject.SetActive(true);
            texto.text = "WASHING MACHINE - MÁQUINA DE LAVAR";
        }
    }

    //Objeto Pia
    if (trigg == 4 && varenemy == 0)
    {
        if (Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.E))
        {
            box.gameObject.SetActive(true);
            texto.gameObject.SetActive(true);
            texto.text = "SINK - PIA";
        }
    }

    //Objeto Desentupidor
    if (trigg == 5 && varenemy == 0)
    {
        if (Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.E))
        {
            box.gameObject.SetActive(true);
            texto.gameObject.SetActive(true);
            texto.text = "PLUNGER - DESENTUPIDOR";
        }
    }

    //Objeto Privada

    if (trigg == 6 && varenemy == 0)
    {
        if (Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.E))
        {
            box.gameObject.SetActive(true);
            texto.gameObject.SetActive(true);
            texto.text = "TOILET - PRIVADA";
        }
    }

    //Objeto Toalha

    if (trigg == 7 && varenemy == 0)
    {
        if (Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.E))
        {
            box.gameObject.SetActive(true);
            texto.gameObject.SetActive(true);
            texto.text = "TOWEL - TOALHA";
        }
    }

    //Objeto Chuveiro e Banheira

    if (trigg == 8 && varenemy == 0)
    {
        if (Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.E))
        {
            box.gameObject.SetActive(true);
            texto.gameObject.SetActive(true);
            texto.text = "SHOWER - CHUVEIRO" + '\n' +
                "BATHTUB - BANHEIRA";
        }
    }

    //Objeto Cesto de Roupa

    if (trigg == 9 && varenemy == 0)
    {
        if (Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.E))
        {
            box.gameObject.SetActive(true);
            texto.gameObject.SetActive(true);
            texto.text = "HAMPER - CESTO";
            saidap1.gameObject.SetActive(true);
        }
    }

    //Quando o usuário tentar sair da sala mas ainda não tiver derrotado o chefão:
    if (trigg == 10 && windoor1 == 0)
    {
        if (Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.E))
        {
            enemy.gameObject.SetActive(true);
            box.gameObject.SetActive(true);
            texto.gameObject.SetActive(true);
            texto.text = "SINTO CHEIRO DE FORASTEIRO";
            varenemy = 1;
        }
    }

    //Se o usuário estiver no trigger e a variavel que identifica se o inimigo apareceu na tela for  1, abre-se a tela de luta:
    if (trigg == 0 && varenemy == 1 && combate != 1)
    {
        enemy.gameObject.SetActive(false);
        box.gameObject.SetActive(false);
        texto.gameObject.SetActive(false);
        bath.gameObject.SetActive(false);
        lim_bath.gameObject.SetActive(false);
        triggbath.gameObject.SetActive(false);
        saidap1.gameObject.SetActive(false);
        telacombate.gameObject.SetActive(true);
        textocombate.gameObject.SetActive(true);
        if (Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.E))
            combate = 1;
            go();
    }
        go();
    }


    void go()
    {


        if (varenemy == 1 && combate == 1 && count <= 10)
        {
            textocombate.gameObject.SetActive(false);
            obj1.gameObject.SetActive(true);
            sort = UnityEngine.Random.Range(0, 7);
            sortt.text = bath_obj[sort];

            if (sortt.text == "SINK")
            {
                if (trigg == 4)
                {
                    if (Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.E)) count++;
                }
            }

            else if (sortt.text == "TOWEL")
            {
                if (trigg == 7)
                {
                    if (Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.E)) count++;
                }
            }

            else if (sortt.text == "TOILET")
            {
                if (trigg == 6)
                {
                    if (Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.E)) count++;
                }
            }

            else if (sortt.text == "WASHING MACHINE")
            {
                if (trigg == 3)
                {
                    if (Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.E)) count++;
                }
            }

            else if (sortt.text == "PLUNGER")
            {
                if (trigg == 5)
                {
                    if (Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.E)) count++;
                }
            }

            else if (sortt.text == "SHOWER")
            {
                if (trigg == 8)
                {
                    if (Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.E)) count++;
                }
            }

            else if (sortt.text == "BATHTUB")
            {
                if (trigg == 11)
                {
                    if (Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.E)) count++;
                }
            }

            else if (sortt.text == "HAMPER")
            {
                if (trigg == 9)
                {
                    if (Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.E)) count++;
                }
            }
        }

    }




        private void FixedUpdate()
        {
            //movimentação do personagem
            float horizontal;
            float vertical;
            horizontal = (int)(Input.GetAxisRaw("Horizontal"));
            vertical = (int)(Input.GetAxisRaw("Vertical"));
            a.SetFloat("horizontal", horizontal);
            a.SetFloat("vertical", vertical);
        }

        void Movimentacao()
        {

            if (Input.GetAxisRaw("Horizontal") > 0)
            {
                personagem.gameObject.transform.Translate(Vector2.right * speed * Time.deltaTime);
                // personagem.gameObject.transform.eulerAngles = new Vector2(0, 0);

            }
            if (Input.GetAxisRaw("Horizontal") < 0)
            {
                personagem.gameObject.transform.Translate(Vector2.left * speed * Time.deltaTime);
                // personagem.gameObject.transform.eulerAngles = new Vector2(0, 0);
            }
            if (Input.GetAxisRaw("Vertical") > 0)
            {
                personagem.gameObject.transform.Translate(Vector2.up * speed * Time.deltaTime);
                //personagem.gameObject.transform.eulerAngles = new Vector2(0, 0);
            }
            if (Input.GetAxisRaw("Vertical") < 0)
            {
                personagem.gameObject.transform.Translate(Vector2.down * speed * Time.deltaTime);
                // personagem.gameObject.transform.eulerAngles = new Vector2(0, 0);
            }
        }

        private void OnTriggerStay2D(Collider2D collision)
        {
            if (collision.gameObject.tag == "Ent_c1") trigg = 1;

            else if (collision.gameObject.tag == "Door1") trigg = 2;

            else if (collision.gameObject.tag == "T_maq") trigg = 3;

            else if (collision.gameObject.tag == "T_pia") trigg = 4;

            else if (collision.gameObject.tag == "T_desent") trigg = 5;

            else if (collision.gameObject.tag == "T_privada") trigg = 6;

            else if (collision.gameObject.tag == "T_toalha") trigg = 7;

            else if (collision.gameObject.tag == "T_chuveiro") trigg = 8;

            else if (collision.gameObject.tag == "T_cesto") trigg = 9;

            else if (collision.gameObject.tag == "saidap1") trigg = 10;

            else if (collision.gameObject.tag == "T_banheiro") trigg = 11;


        }
        private void OnTriggerExit2D(Collider2D collision)
        {
            if (collision.gameObject.tag == "Ent_c1") trigg = 0;
            if (collision.gameObject.tag == "Door1") trigg = 0;
            if (collision.gameObject.tag == "T_maq") trigg = 0;
            if (collision.gameObject.tag == "T_pia") trigg = 0;
            if (collision.gameObject.tag == "T_desent") trigg = 0;
            if (collision.gameObject.tag == "T_privada") trigg = 0;
            if (collision.gameObject.tag == "T_toalha") trigg = 0;
            if (collision.gameObject.tag == "T_chuveiro") trigg = 0;
            if (collision.gameObject.tag == "T_cesto") trigg = 0;
            if (collision.gameObject.tag == "saidap1") trigg = 0;
            if (collision.gameObject.tag == "T_banheiro") trigg = 0;

        }

        void PrimeiraPorta()
        {
            if (Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.E))
            {
                corredor.gameObject.SetActive(false);
                personagem.gameObject.transform.position = (new Vector2(-2.020084f, -1.691f));
                bath.gameObject.SetActive(true);
                lim_corr.gameObject.SetActive(false);
                lim_bath.gameObject.SetActive(true);
                trigg = 0;
            }

        }
    }






