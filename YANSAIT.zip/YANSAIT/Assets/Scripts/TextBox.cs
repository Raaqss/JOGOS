﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;
using UnityEngine.Audio;
public class TextBox : MonoBehaviour
{

    public GameObject ti;
    public Text intro;
    public AudioClip q;
    public AudioClip f;
    AudioSource source;
    public GameObject caixa;
    public Text dialogo;

    private void Awake()
    {
        source = GetComponent<AudioSource>();
        source.clip = q;
        source.Play();

    }
    private void FixedUpdate()
    {
        Vector3 pos1 = new Vector3(1, 1, 7);
        Vector3 pos2 = new Vector3(0, 0, 0);
        if (Time.timeSinceLevelLoad >= 1.2 && Time.timeSinceLevelLoad < 2.5)
        {
            intro.text = "O que?...";
            source.Stop();
        }
        if (Time.timeSinceLevelLoad >= 2.5 && Time.timeSinceLevelLoad < 4) intro.text = "Onde estou?";
        if (Time.timeSinceLevelLoad >= 4 && Time.timeSinceLevelLoad < 4.3)
        {
            intro.text = "";
            caixa.gameObject.SetActive(false);
        }
        if (Time.timeSinceLevelLoad >= 4.3 && Time.timeSinceLevelLoad <= 5.38) ti.transform.Rotate(pos1);
        if (Time.timeSinceLevelLoad > 5.38 && Time.timeSinceLevelLoad < 5.9) ti.gameObject.SetActive(false);
        if (Time.timeSinceLevelLoad >= 5.9 && Time.timeSinceLevelLoad < 6f)
            {
              source.clip = f;
                source.Play();
            }
        if(Time.timeSinceLevelLoad>=12.3 && Time.timeSinceLevelLoad < 16)
        {
            source.volume = 0.3f;
            caixa.gameObject.SetActive(true);
            dialogo.text = "Mayor: Saudações, forasteiro! Seja bem vindo a nossa vila.";

        }
        if (Time.timeSinceLevelLoad >= 16 && Time.timeSinceLevelLoad < 23) dialogo.text = " Nikols: O quê? Quem é você? Onde estou?";
        if (Time.timeSinceLevelLoad >= 23 && Time.timeSinceLevelLoad < 30) dialogo.text = "Mayor: Me chamo Mayor, e você esta na Vila, para a sua sorte eu te encontrei antes dos outros...";
        if (Time.timeSinceLevelLoad >= 30 && Time.timeSinceLevelLoad < 35) dialogo.text = "Nikols: Como assim para a minha sorte?";
        if (Time.timeSinceLevelLoad >= 35 && Time.timeSinceLevelLoad < 45) dialogo.text = "Mayor: Bem, como posso dizer isso? Os moradores dessa vila, não são exatamente amigaveis com forasteiros como você.";
        if (Time.timeSinceLevelLoad >= 45 && Time.timeSinceLevelLoad < 50) dialogo.text = "Nikols: E como eles saberiam que sou um forasteiro?";
        if (Time.timeSinceLevelLoad >= 50 && Time.timeSinceLevelLoad < 60) dialogo.text = "Mayor: Pra começar você não fala nosso idioma local, o idioma que falamos, é conhecido como 'inglês'.";
        if (Time.timeSinceLevelLoad >= 60 && Time.timeSinceLevelLoad < 65) dialogo.text = "Nikols: Sendo assim, como você me entende?";
        if (Time.timeSinceLevelLoad >= 65 && Time.timeSinceLevelLoad < 72) dialogo.text = "Mayor: Ah meu jovem, poucos são os idiomas que eu não conheço.";
        if (Time.timeSinceLevelLoad >= 72 && Time.timeSinceLevelLoad < 78) dialogo.text = "Nikols: Certo...E o que acontece se descobrirem que eu sou um forasteiro?";
        if (Time.timeSinceLevelLoad >= 78 && Time.timeSinceLevelLoad < 84) dialogo.text = "Mayor: Nesse caso, temo em lhe dizer que dificilmente você sairá daqui com vida...";
        if (Time.timeSinceLevelLoad >= 84 && Time.timeSinceLevelLoad < 88) dialogo.text = "Nikols: O QUE????";
        if (Time.timeSinceLevelLoad >= 88 && Time.timeSinceLevelLoad < 92) dialogo.text = "Mayor: ...";
        if (Time.timeSinceLevelLoad >= 92 && Time.timeSinceLevelLoad < 99) dialogo.text = "Nikols: E como eu faço pra sair vivo?";
        if (Time.timeSinceLevelLoad >= 99 && Time.timeSinceLevelLoad < 115) dialogo.text = "Mayor: Para sair da Vila vivo, será necessário aprender o idioma local, fingindo ser um morador.";
        if (Time.timeSinceLevelLoad >= 115 && Time.timeSinceLevelLoad < 120) dialogo.text = "Nikols: Err...E como eu faço isso?";
        if (Time.timeSinceLevelLoad >= 120 && Time.timeSinceLevelLoad < 130) dialogo.text = "Mayor: Bem, para isso você deverá explorar a vila, tenho certeza que você encontrará o seu caminho, mas tome cuidado! A qualquer momento um morador local pode suspeitar de você.";
        if (Time.timeSinceLevelLoad >= 130 && Time.timeSinceLevelLoad < 140) dialogo.text = "Nikols: Ótimo, me sinto bem mais tranquilo agora...Você não pode me ajudar?";
        if (Time.timeSinceLevelLoad >= 140 && Time.timeSinceLevelLoad < 155) dialogo.text = "Mayor: Infelizmente você deve encontrar o seu caminho sozinho, mas não se preocupe, eu aparecerei nos momentos certos. Agora vá, entre na primeira cabana e explore seus caminhos forasteiro, que a sorte esteja com você!";
        if (Time.timeSinceLevelLoad >= 155 && Time.timeSinceLevelLoad <= 157) dialogo.text = " ";
        if(Time.timeSinceLevelLoad >=157 && Time.timeSinceLevelLoad <162) dialogo.text = "Nikols: QUE? Ele sumiu...";
        if (Time.timeSinceLevelLoad >= 162 && Time.timeSinceLevelLoad < 168) dialogo.text="Nikols: Bem, ao menos eu sei por onde começar...";
        if (Time.timeSinceLevelLoad >= 168 && Time.timeSinceLevelLoad <=170) Destroy(caixa);
        if(Time.timeSinceLevelLoad >170) SceneManager.LoadScene("Game");
        }
        
    }
        

    

        




