﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;



public class Titulo : MonoBehaviour {
    public Text title;
    public Text options;
    public Text selecao;
    public Text start;

    // Update is called once per frame
   private void FixedUpdate()
    {
        selecao.color = Color.black;
        start.color = Color.black;
        options.color = Color.black;

        if(Time.timeSinceLevelLoad >=0.5 && Time.timeSinceLevelLoad < 1)
            title.text = "Y";
        if (Time.timeSinceLevelLoad >= 1 && Time.timeSinceLevelLoad < 1.5)
            title.text = "YA";
        if (Time.timeSinceLevelLoad >= 1.5 && Time.timeSinceLevelLoad < 2)
            title.text = "YAN";
        if (Time.timeSinceLevelLoad >= 2 && Time.timeSinceLevelLoad < 2.5)
            title.text = "YANS";
        if (Time.timeSinceLevelLoad >= 2.5 && Time.timeSinceLevelLoad < 3)
            title.text = "YANSA";
        if (Time.timeSinceLevelLoad >= 3 && Time.timeSinceLevelLoad < 3.5)
            title.text = "YANSAI";
        if (Time.timeSinceLevelLoad >= 3.5 && Time.timeSinceLevelLoad < 3.8)
            title.text = "YANSAIT";

        if (Time.timeSinceLevelLoad >= 3.8 && Time.timeSinceLevelLoad < 4)
            title.color = Color.black;
        if (Time.timeSinceLevelLoad >= 4 && Time.timeSinceLevelLoad < 4.5)
            title.color = Color.red;
        if (Time.timeSinceLevelLoad >= 4.5 && Time.timeSinceLevelLoad < 5)
            title.color = Color.yellow;
        if (Time.timeSinceLevelLoad >= 5 && Time.timeSinceLevelLoad < 5.5)
            title.color = Color.green;
        if (Time.timeSinceLevelLoad >= 5.5 && Time.timeSinceLevelLoad < 6)
            title.color = Color.black;
        if (Time.timeSinceLevelLoad >= 6 && Time.timeSinceLevelLoad < 6.5)
            title.color = Color.white;
        if (Time.timeSinceLevelLoad >= 6.5) 
        {
            options.color = Color.white;
            start.color = Color.white;
            selecao.color = Color.white;
            selecao.text = "◄";
        }

        if (Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.KeypadEnter) || Input.GetKey(KeyCode.E)){
            SceneManager.LoadScene("Intro");
        }
        }
    }     //  title.text.




